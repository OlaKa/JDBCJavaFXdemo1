CREATE PROCEDURE `GetEleverByKlasskod`(IN `Personnummer` CHAR(10), OUT `Klassnamn` VARCHAR(50))
  BEGIN
    SELECT Klass.Namn INTO Klassnamn FROM Elev
      INNER JOIN Klass ON Elev.Klasskod = Klass.Kod
      WHERE Elev.Personnummer=Personnummer;

  END